create definer = root@localhost view topic_view as
select `education`.`section`.`sID`     AS `sID`,
       `education`.`topic`.`tTopic`    AS `tTopic`,
       `education`.`topic`.`tContents` AS `tContents`,
       `education`.`topic`.`tTime`     AS `tTime`
from (`education`.`section`
         join `education`.`topic`)
where (`education`.`section`.`sID` = `education`.`topic`.`tID`);

